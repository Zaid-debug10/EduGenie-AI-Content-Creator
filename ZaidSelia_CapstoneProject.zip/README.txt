EduGenie: AI-Powered Educational Content Creator
Capstone Project for Internshala Generative AI Course
Submitted by: Zaid Selia
Date: April 07, 2025

Project Description:
EduGenie is a web-based AI tool that generates educational content based on a user-provided course title. It uses HTML, CSS, and JavaScript for the frontend, and is designed to integrate with OpenAI's API for content generation (mock response used in this version).

Features:
- Simple UI with input field for course title and a "Generate Content" button.
- Displays generated content: course objective, sample syllabus, three measurable learning outcomes (aligned with Bloom's Taxonomy), assessment methods, and recommended readings.
- Includes a "Copy" button to copy the generated content.
- Data privacy notice to ensure user trust.
- Error handling for empty inputs.
- Loading state while content is being generated.

How to Run:
1. Save the `edugenie.html` file on your computer.
2. Open it in a web browser (e.g., Chrome, Firefox).
3. Enter a course title (e.g., "Operating Systems") and click "Generate Content".
4. View the generated content and use the "Copy" button to copy it.

Note:
- This version uses a mock response for the OpenAI API. To integrate the actual OpenAI API, you need to:
  1. Set up a backend server (e.g., using Python Flask).
  2. Add your OpenAI API key.
  3. Make an API call to OpenAI's endpoint and return the response to the frontend.
- Internet connection is required for the actual API integration.

Testing:
- Tested on Chrome and Firefox with various course titles.
- Error handling works for empty inputs.
- Copy functionality works across browsers.